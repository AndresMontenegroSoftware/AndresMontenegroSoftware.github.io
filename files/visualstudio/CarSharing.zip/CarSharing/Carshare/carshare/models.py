from django.db import models

class Country(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = models.TextField("Country", null=False)
	iso = models.CharField("ISO 2", max_length=2, null=False)
	iso3 = models.CharField("ISO 3", max_length=3, null=True)
	numcode = models.IntegerField("Numeric Code", null=True)

class City(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	country = models.ForeignKey(Country, null=False)
	name = models.TextField("City", null=False)

class TransmissionType(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = TextField("Transmission Type", null= False)

class VehicleType(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = TextField("Vehicle Type", null= False)

class InsuranceType(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = TextField("Insurance Type", null= False)

class OdometerRange(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = TextField("Odometer Range", null= False)

class MarketValueRange(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = TextField("Market Value Range", null= False)

class AdvanceNoticeRange(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = TextField("Advance Notice Range", null= False)

class MinTripRange(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = TextField("Min. Trip Range", null= False)

class MaxTripRange(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = TextField("Max. Trip Range", null= False)

class Year(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = models.IntegerField("Year",null=False)

class Make(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = models.TextField("Make", null=False)
	country = models.ForeignKey(Country, null=False)

class Model(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	make = models.ForeignKey(Make, null=False)
	name = models.TextField("Model", null=False)
	year = models.ForeignKey(Year, null=False)
	vehicleType = models.ForeignKey(VehicleType, null=False)

class Trim(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	model = models.ForeignKey(Model, null=False)
	name = models.TextField("Trim", null=False)

class User(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	firstName = models.TextField("First Name", null=False)
	lastName = models.TextField("Last Name", null=False)
	email = models.TextField("E-Mail", null=False)
	phone = models.IntegerField("Phone", null=True)
	smsOn = models.BooleanField("SMS Notifications",default=True,null=False)
	promotionsOn = models.BooleanField("Promotions",default=True,null=False)
	expertTransmission = models.BooleanField("Expert Transmission",default=True,null=False)
	driverApproved = models.BooleanField("Approved Driver",default=False,null=False)

class Car(models.Model):
	id = models.AutoField("Id", primary_key=True, null=False)
	country = models.ForeignKey(Country,null=False)
	city = models.ForeignKey(City, null=False)
	location = models.TextField("Car Location", null=False)
	year = models.ForeignKey(Year, null=False)
	make = models.ForeignKey(Make, null=False)
	model = models.ForeignKey(Model, null=False)
	trim = models.ForeignKey(Trim, null=True)
	transmission = models.ForeignKey(TransmissionType, null=False)
	vehicleType = models.ForeignKey(VehicleType, null=False)
	insuranceType = models.ForeignKey(InsuranceType, null=False)
	odometer = models.ForeignKey(OdometerRange, null=False)
	marketValue = models.ForeignKey(MarketValueRange, null=False)
	advanceNotice = models.ForeignKey(AdvanceNoticeRange, null=False)
	minTrip = models.ForeignKey(MinTripRange, null=False)
	maxTrip = models.ForeignKey(MaxTripRange, null=False)
	licensePlate = models.TextField("License Plate", null=False)
	dayRate = models.FloatField("Day Rate", null=False)
	milesPerDayIncluded = models.IntegerField("Miles Included Per Day", null=True)
	extraMilesFree = models.FloatField("Fee Per Extra Mile", null=True)
	guidelines = models.TextField("Guidelines", null=True)
	description = models.TextField("Description", null=True)

class Trip(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	guest = models.ForeignKey(User, null=False)
	car = models.ForeignKey(Car, null=False)
	startDate = models.DateTimeField("Start Date", null=False)
	endDate = models.DateTimeField("End Date", null=False)
	pickupLocation = models.TextField("Pick-up Location", null=False)
	price = models.FloatField("Total", null=False)

class Feature(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	name = models.TextField("Feature", null=False)

class CarFeature(models.Model):
	car = models.ForeignKey(Car, null=False)
	feature = models.ForeignKey(Feature, null=False)

class CarOwner(models.Model):
	car = models.ForeignKey(Car, null=False)
	owner = models.ForeignKey(User, null=False)

class TripDriver(models.Model):
	trip = models.ForeignKey(Trip, null=False)
	driver = models.ForeignKey(User, null=False)

class DriverLicense(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	user = models.OneToOneField(User, null=False)
	firstName = models.TextField("First Name", null=False)
	lastName = models.TextField("Last Name", null=False)
	licenseId = models.TextField("License Id Number", null=False)
	birthDate = models.DateField("Birth Date", null=False)

class Insurance(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	companyName = models.TextField("Company Name", null=False)
	companyAddress = models.TextField("Company Address", null=True)
	website = models.TextField("Website", null=True)
	phone = models.IntegerField("Phone", null=False)
	insuranceProvider = models.TextField("Insurance Provider", null=False)
	policyNumber = models.TextField("Policy Number", null=False)
	expirationDate = models.DateField("Expiration Date", null=True)

class CarInsurance(models.Model):
	car = models.ForeignKey(Car, null=False)
	insurance = models.ForeignKey(Insurance, null=False)

class ProfilePicture(models.Model):
	user = models.OneToOneField(User, null=False)
	imagePath = models.TextField("Image Path", null=False)

class CarPicture(models.Model):
	car = models.ForeignKey(Car, null=False)
	imagePath = models.TextField("Image Path", null=False)

class Security(models.Model):
	code = models.AutoField("Id", primary_key=True, null=False)
	user = models.ForeignKey(User, null=False)
	nickname = models.TextField("Nickname", null=True)
	password = models.TextField("Password", null=False



